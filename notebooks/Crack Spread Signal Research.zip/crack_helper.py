"""Crack-spread research helpers.

This module keeps crack-spread notebook utility code out of the notebook while
reusing the shared analytical helpers already maintained in ``helper.py``.
"""

from __future__ import annotations

from typing import Mapping, Sequence

import numpy as np
import pandas as pd

from helper import (
    _build_signal_from_config,
    bootstrap_ic_ci,
    build_family_signal_panel,
    build_signal_target_position_panel,
    compute_bucket_stats,
    compute_drawdown_stats,
    compute_forward_change,
    compute_position_turnover,
    compute_predictive_corr_stats,
    compute_sharpe_raw,
    compute_sortino_raw,
    compute_terminal_change,
    compute_top_drawdowns,
    evaluate_signal_grid,
    prepare_backtest_frame,
    rolling_percentile_rank,
    summarise_regime_family,
)


CRACK_SIGNAL_LABELS = {
    "stress_trend": "Stress trend",
    "stress_mean_reversion": "Stress mean reversion",
    "normal_trend": "Normal trend",
    "normal_mean_reversion": "Normal mean reversion",
}


def signal_label(signal_name: str) -> str:
    """Return a display label for a crack-spread signal name.

    Parameters
    ----------
    signal_name:
        Internal signal identifier.

    Returns
    -------
    str
        Human-readable signal label.
    """
    return CRACK_SIGNAL_LABELS.get(signal_name, signal_name.replace("_", " ").title())


def build_roll_flag(marks: pd.DataFrame) -> pd.Series:
    """Identify dates where the active MID-rolled contract symbol changes.

    Parameters
    ----------
    marks:
        Marking DataFrame returned by ``get_structured_markings`` with a
        ``symbol`` column that identifies the active structured contract.

    Returns
    -------
    pd.Series
        Boolean roll-date indicator indexed like ``marks``. The first available
        row is not treated as a roll because there is no prior held contract.
    """
    if "symbol" not in marks.columns:
        raise ValueError("marks must contain a symbol column to identify roll dates.")

    symbol = marks["symbol"].astype("string")
    return (symbol.ne(symbol.shift()) & symbol.shift().notna()).fillna(False).rename("is_roll_date")


def infer_spread_from_panel_column(column_name: str, spread_names: list[str]) -> str:
    """Infer the spread name from a portfolio panel column.

    Parameters
    ----------
    column_name:
        Portfolio column, either a spread name or ``<spread>_<signal>``.
    spread_names:
        Valid spread names to match against.

    Returns
    -------
    str
        Matched spread name.
    """
    for spread_name in sorted(spread_names, key=len, reverse=True):
        if column_name == spread_name or column_name.startswith(f"{spread_name}_"):
            return spread_name
    raise ValueError(f"Cannot infer spread name from column: {column_name}")


def build_roll_flag_panel(
    columns: pd.Index,
    index: pd.Index,
    spread_roll_flags: Mapping[str, pd.Series],
) -> pd.DataFrame:
    """Build a roll-date panel aligned to portfolio columns and timestamps.

    Parameters
    ----------
    columns:
        Portfolio leg columns.
    index:
        Timestamp index for the target positions.
    spread_roll_flags:
        Roll-date indicators keyed by spread name.

    Returns
    -------
    pd.DataFrame
        Boolean roll-date panel with the same index and columns as the target
        position panel.
    """
    roll_columns = {}
    spread_names = list(spread_roll_flags.keys())
    for column_name in columns:
        spread_name = infer_spread_from_panel_column(str(column_name), spread_names)
        roll_columns[column_name] = spread_roll_flags[spread_name].reindex(index).fillna(False).astype(bool)
    return pd.DataFrame(roll_columns, index=index)


def apply_position_change_threshold(
    desired_positions: pd.DataFrame,
    position_change_threshold: float,
) -> pd.DataFrame:
    """Suppress small position updates while always allowing flat exits.

    Parameters
    ----------
    desired_positions:
        Desired portfolio positions indexed by timestamp and leg.
    position_change_threshold:
        Minimum absolute per-leg change required before updating a non-flat
        target. Exact flat targets are always applied.

    Returns
    -------
    pd.DataFrame
        Realised positions after threshold filtering.
    """
    if position_change_threshold < 0:
        raise ValueError("position_change_threshold must be non-negative.")
    if desired_positions.empty:
        return desired_positions.copy()

    filtered_rows = []
    current = pd.Series(0.0, index=desired_positions.columns)
    for _, desired in desired_positions.iterrows():
        desired = desired.fillna(0.0)
        delta = (desired - current).abs()
        should_trade = (delta >= position_change_threshold) | ((desired == 0.0) & (current != 0.0))
        current = current.where(~should_trade, desired)
        filtered_rows.append(current.copy())

    return pd.DataFrame(filtered_rows, index=desired_positions.index, columns=desired_positions.columns)


def compute_position_pnl_with_roll(
    signal: pd.Series,
    realised_change: pd.Series,
    roll_flag: pd.Series,
    one_way_cost: float,
    roll_cost: float,
) -> pd.Series:
    """Compute sign-based PnL with trading and contract-roll costs.

    Parameters
    ----------
    signal:
        Signal series aligned to the realised change.
    realised_change:
        Future realised price change already shifted onto the signal timestamp.
    roll_flag:
        Boolean indicator for dates where the active structured contract rolls.
    one_way_cost:
        Cost charged per one unit of absolute position change.
    roll_cost:
        Cost charged per one unit of active position on roll dates.

    Returns
    -------
    pd.Series
        Net PnL after trading and roll costs.
    """
    position = np.sign(signal).fillna(0.0)
    aligned_change = realised_change.reindex(position.index).fillna(0.0)
    aligned_roll = roll_flag.reindex(position.index).fillna(False).astype(float)
    position_change = position.diff().abs().fillna(position.abs())
    gross_pnl = position * aligned_change
    trading_cost = position_change * one_way_cost
    roll_cost_drag = position.abs() * aligned_roll * roll_cost
    return (gross_pnl - trading_cost - roll_cost_drag).rename(
        signal.name if signal.name is not None else "roll_aware_net_pnl"
    )


def compute_position_pnl_from_target_with_roll(
    target_position: pd.Series,
    realised_change: pd.Series,
    roll_flag: pd.Series,
    one_way_cost: float,
    roll_cost: float,
) -> pd.Series:
    """Compute target-position PnL with trading and contract-roll costs.

    Parameters
    ----------
    target_position:
        Explicit target position aligned to the signal timestamp.
    realised_change:
        Future realised price change already shifted onto the signal timestamp.
    roll_flag:
        Boolean indicator for dates where the active structured contract rolls.
    one_way_cost:
        Cost charged per one unit of absolute position change.
    roll_cost:
        Cost charged per one unit of active position on roll dates.

    Returns
    -------
    pd.Series
        Net PnL after trading and roll costs.
    """
    position = target_position.fillna(0.0)
    aligned_change = realised_change.reindex(position.index).fillna(0.0)
    aligned_roll = roll_flag.reindex(position.index).fillna(False).astype(float)
    position_change = position.diff().abs().fillna(position.abs())
    gross_pnl = position * aligned_change
    trading_cost = position_change * one_way_cost
    roll_cost_drag = position.abs() * aligned_roll * roll_cost
    return (gross_pnl - trading_cost - roll_cost_drag).rename(
        target_position.name if target_position.name is not None else "target_roll_aware_net_pnl"
    )


def compute_portfolio_pnl_from_target_positions_with_roll(
    target_panel: pd.DataFrame,
    realised_change_panel: pd.DataFrame,
    spread_roll_flags: Mapping[str, pd.Series],
    one_way_cost: float,
    roll_cost: float,
    rebalance_rule: str | None = None,
    position_change_threshold: float | None = None,
    normalise_by_active_count: bool = True,
    pnl_name: str = "target_portfolio_roll_aware_net_pnl",
) -> tuple[pd.Series, pd.DataFrame]:
    """Compute portfolio PnL from target positions with roll costs.

    Parameters
    ----------
    target_panel:
        Position targets by leg. ``NaN`` means the leg is inactive.
    realised_change_panel:
        Realised changes aligned to target timestamps.
    spread_roll_flags:
        Roll-date indicators keyed by spread name.
    one_way_cost:
        Cost charged per one unit of absolute position change.
    roll_cost:
        Cost charged per one unit of active position on roll dates.
    rebalance_rule:
        Optional pandas resample rule. If omitted, targets update when they change.
    position_change_threshold:
        Optional absolute target-change threshold used to suppress small trades.
    normalise_by_active_count:
        If true, divide each row by the number of active non-null legs.
    pnl_name:
        Name for the returned PnL series.

    Returns
    -------
    tuple[pd.Series, pd.DataFrame]
        Net portfolio PnL and realised positions after trading and roll costs.
    """
    aligned_targets = target_panel.dropna(how="all").copy()
    aligned_changes = realised_change_panel.reindex(aligned_targets.index).copy()

    if rebalance_rule is not None:
        sampled_targets = aligned_targets.resample(rebalance_rule).last()
        desired_targets = sampled_targets.reindex(aligned_targets.index, method="ffill")
    else:
        desired_targets = aligned_targets

    if normalise_by_active_count:
        active_counts = desired_targets.notna().sum(axis=1).replace(0, np.nan)
        desired_positions = desired_targets.div(active_counts, axis=0)
    else:
        desired_positions = desired_targets

    desired_positions = desired_positions.fillna(0.0)
    if position_change_threshold is not None and position_change_threshold > 0:
        positions = apply_position_change_threshold(desired_positions, position_change_threshold)
    else:
        positions = desired_positions

    position_change = positions.diff().abs().fillna(positions.abs())
    roll_flag_panel = build_roll_flag_panel(positions.columns, positions.index, spread_roll_flags).astype(float)
    gross_pnl = (positions * aligned_changes.fillna(0.0)).sum(axis=1)
    trading_cost = position_change.sum(axis=1) * one_way_cost
    roll_cost_drag = (positions.abs() * roll_flag_panel).sum(axis=1) * roll_cost
    net_pnl = gross_pnl - trading_cost - roll_cost_drag
    return net_pnl.rename(pnl_name), positions


def compute_family_pnl_with_roll(
    signal_panel: pd.DataFrame,
    realised_change_panel: pd.DataFrame,
    spread_roll_flags: Mapping[str, pd.Series],
    one_way_cost: float,
    roll_cost: float,
    rebalance_rule: str | None = None,
    pnl_name: str = "family_roll_aware_net_pnl",
) -> tuple[pd.Series, pd.DataFrame]:
    """Compute equal-weighted sign portfolio PnL with roll costs.

    Parameters
    ----------
    signal_panel:
        Signal panel by spread-signal leg.
    realised_change_panel:
        Realised changes aligned to signal timestamps.
    spread_roll_flags:
        Roll-date indicators keyed by spread name.
    one_way_cost:
        Cost charged per one unit of absolute position change.
    roll_cost:
        Cost charged per one unit of active position on roll dates.
    rebalance_rule:
        Optional pandas resample rule.
    pnl_name:
        Name for the returned PnL series.

    Returns
    -------
    tuple[pd.Series, pd.DataFrame]
        Net portfolio PnL and realised positions.
    """
    aligned_signals = signal_panel.dropna().copy()
    aligned_changes = realised_change_panel.reindex(aligned_signals.index).copy()
    target_panel = np.sign(aligned_signals)
    return compute_portfolio_pnl_from_target_positions_with_roll(
        target_panel,
        aligned_changes,
        spread_roll_flags=spread_roll_flags,
        one_way_cost=one_way_cost,
        roll_cost=roll_cost,
        rebalance_rule=rebalance_rule,
        normalise_by_active_count=True,
        pnl_name=pnl_name,
    )


def compute_switching_family_pnl_with_roll(
    frames: Mapping[str, pd.DataFrame],
    signal_order: Sequence[str],
    stress_signals: Sequence[str],
    normal_signals: Sequence[str],
    horizon_days: int,
    spread_roll_flags: Mapping[str, pd.Series],
    one_way_cost: float,
    roll_cost: float,
    rebalance_rule: str | None = None,
) -> tuple[pd.Series, pd.DataFrame]:
    """Compute volatility-switching portfolio PnL with roll costs.

    Parameters
    ----------
    frames:
        Prepared backtest frames keyed by spread name.
    signal_order:
        Signal names to include.
    stress_signals:
        Signal names active in high-volatility regimes.
    normal_signals:
        Signal names active outside high-volatility regimes.
    horizon_days:
        Forward horizon used for realised changes.
    spread_roll_flags:
        Roll-date indicators keyed by spread name.
    one_way_cost:
        Cost charged per one unit of absolute position change.
    roll_cost:
        Cost charged per one unit of active position on roll dates.
    rebalance_rule:
        Optional pandas resample rule.

    Returns
    -------
    tuple[pd.Series, pd.DataFrame]
        Net switching-portfolio PnL and realised positions.
    """
    combined_signal_columns = {}
    combined_change_columns = {}

    for spread_name, frame in frames.items():
        for signal_name in signal_order:
            column_name = f"{spread_name}_{signal_name}"
            active_mask = frame["is_stress_regime"] if signal_name in stress_signals else ~frame["is_stress_regime"]
            combined_signal_columns[column_name] = frame[signal_name].where(active_mask)
            combined_change_columns[column_name] = frame[f"terminal_change_{horizon_days}d"].where(active_mask)

    signal_panel = pd.DataFrame(combined_signal_columns).dropna(how="all")
    realised_change_panel = pd.DataFrame(combined_change_columns).reindex(signal_panel.index)
    target_panel = np.sign(signal_panel)
    return compute_portfolio_pnl_from_target_positions_with_roll(
        target_panel,
        realised_change_panel,
        spread_roll_flags=spread_roll_flags,
        one_way_cost=one_way_cost,
        roll_cost=roll_cost,
        rebalance_rule=rebalance_rule,
        normalise_by_active_count=True,
        pnl_name="switching_roll_aware_net_pnl",
    )


def build_switching_target_and_change_panels(
    frames: Mapping[str, pd.DataFrame],
    sizing_method: str,
    signal_configs: Mapping[str, Mapping[str, object]],
    signal_order: Sequence[str],
    stress_signals: Sequence[str],
    horizon_days: int,
    clip_value: float,
    rank_deadband: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build active switching target and realised-change panels.

    Parameters
    ----------
    frames:
        Prepared backtest frames keyed by spread name.
    sizing_method:
        Position-sizing rule passed to ``build_signal_target_position_panel``.
    signal_configs:
        Signal configuration mapping.
    signal_order:
        Signal names to include.
    stress_signals:
        Signal names active in high-volatility regimes.
    horizon_days:
        Forward horizon used for realised changes.
    clip_value:
        Symmetric clip for trend-scaled positions.
    rank_deadband:
        Neutral percentile-rank band for mean-reversion positions.

    Returns
    -------
    tuple[pd.DataFrame, pd.DataFrame]
        Target-position panel and realised-change panel.
    """
    target_columns = {}
    change_columns = {}

    for spread_name, frame in frames.items():
        target_panel = build_signal_target_position_panel(
            frame,
            signal_configs=signal_configs,
            signal_order=signal_order,
            sizing_method=sizing_method,
            clip_value=clip_value,
            rank_deadband=rank_deadband,
        )

        for signal_name in signal_order:
            col = f"{spread_name}_{signal_name}"
            active_mask = frame["is_stress_regime"] if signal_name in stress_signals else ~frame["is_stress_regime"]
            target_columns[col] = target_panel[signal_name].where(active_mask)
            change_columns[col] = frame[f"terminal_change_{horizon_days}d"].where(active_mask)

    target_panel = pd.DataFrame(target_columns).dropna(how="all")
    change_panel = pd.DataFrame(change_columns).reindex(target_panel.index)
    return target_panel, change_panel


def compute_pnl_t_stat(pnl: pd.Series) -> float:
    """Compute the approximate iid mean-PnL t-statistic used in the notebook.

    Parameters
    ----------
    pnl:
        PnL series to evaluate.

    Returns
    -------
    float
        Approximate t-statistic of mean PnL.
    """
    clean = pnl.dropna()
    return (
        clean.mean() / clean.std(ddof=1) * np.sqrt(len(clean))
        if len(clean) > 1 and clean.std(ddof=1) > 0 else np.nan
    )
