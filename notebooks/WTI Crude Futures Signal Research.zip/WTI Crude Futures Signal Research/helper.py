from typing import List, Dict, Any, Tuple

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

import statsmodels.api as sm


def get_structured_markings() -> Tuple[pd.DataFrame, pd.DataFrame]:
    
    front_marks = pd.read_csv('./front_marks.csv', index_col=0, parse_dates=['ts_ref'])
    marks = pd.read_csv('./marks.csv', index_col=0, parse_dates=['ts_ref'])

    return front_marks, marks


def compute_terminal_change(price_chg: pd.Series, horizon: int) -> pd.Series:
    """Compute the terminal dollar change realised on t+horizon."""
    return price_chg.shift(-horizon)


def _prepare_predictive_inputs(
    signal: pd.Series,
    forward_change: pd.Series,
    method: str = 'spearman',
) -> pd.DataFrame:
    """Align predictive inputs and optionally rank-transform them for Spearman analysis."""
    # Keep both series on the same timestamps before applying any transforms.
    aligned = pd.concat([signal.rename('signal'), forward_change.rename('forward_change')], axis=1).dropna()
    if aligned.shape[0] < 10 or aligned['signal'].nunique() <= 1 or aligned['forward_change'].nunique() <= 1:
        return pd.DataFrame()

    if method == 'spearman':
        # Spearman IC is Pearson correlation on ranks, so rank first.
        x = aligned['signal'].rank(method='average')
        y = aligned['forward_change'].rank(method='average')
    else:
        x = aligned['signal'].astype(float)
        y = aligned['forward_change'].astype(float)

    x_std = x.std(ddof=0)
    y_std = y.std(ddof=0)
    if x_std == 0 or y_std == 0:
        return pd.DataFrame()

    aligned['x'] = (x - x.mean()) / x_std
    aligned['y'] = (y - y.mean()) / y_std
    return aligned


def compute_predictive_corr(signal: pd.Series, forward_change: pd.Series, method: str = 'spearman') -> float:
    """Compute the predictive correlation between a signal and a forward change series."""
    aligned = _prepare_predictive_inputs(signal, forward_change, method=method)
    if aligned.empty:
        return np.nan
    return float(np.corrcoef(aligned['x'], aligned['y'])[0, 1])


def compute_predictive_corr_stats(
    signal: pd.Series,
    forward_change: pd.Series,
    method: str = 'spearman',
    hac_lags: int | None = None,
) -> dict:
    """Compute predictive correlation and a Newey-West t-stat on the same aligned statistic."""
    aligned = _prepare_predictive_inputs(signal, forward_change, method=method)
    if aligned.empty:
        return {'corr': np.nan, 't_stat': np.nan, 'n_obs': 0}

    if hac_lags is None:
        hac_lags = max(1, int(np.ceil(aligned.shape[0] ** (1 / 3))))
    # HAC cannot use more lags than the sample can support.
    hac_lags = min(hac_lags, max(1, aligned.shape[0] - 1))

    X = sm.add_constant(aligned['x'], has_constant='add')
    fit = sm.OLS(aligned['y'], X).fit(cov_type='HAC', cov_kwds={'maxlags': hac_lags})
    return {
        'corr': float(np.corrcoef(aligned['x'], aligned['y'])[0, 1]),
        't_stat': float(fit.tvalues.iloc[1]),
        'n_obs': int(aligned.shape[0]),
    }


def compute_predictive_corr_series(
    signal: pd.Series,
    forward_change: pd.Series,
    method: str = 'spearman',
    window: int = 126,
) -> pd.Series:
    """Compute a rolling predictive correlation series across time."""
    aligned = pd.concat([signal.rename('signal'), forward_change.rename('forward_change')], axis=1).dropna()
    rolling_corr = {}

    for end_idx in range(window, aligned.shape[0] + 1):
        # Each point uses only the trailing window ending at that timestamp.
        sample = aligned.iloc[end_idx - window:end_idx]
        rolling_corr[sample.index[-1]] = compute_predictive_corr(sample['signal'], sample['forward_change'], method=method)

    return pd.Series(rolling_corr, name=f'{method}_rolling_ic')


def compute_signal_turnover(signal: pd.Series) -> float:
    """Compute the average absolute change in sign-implied position."""
    position = np.sign(signal).fillna(0)
    position_change = position.diff().abs().fillna(position.abs())
    return float(position_change.mean())


def compute_position_pnl(signal: pd.Series, realised_change: pd.Series, one_way_cost: float = 0.02) -> pd.Series:
    """Compute net PnL for a persistent-position strategy with cost only on delta position."""
    position = np.sign(signal).fillna(0)
    position_change = position.diff().abs().fillna(position.abs())
    # Use the position against the realised move to avoid look-ahead bias. We assume realised change has already been back-shifted to align with the signal timestamp.
    gross_pnl = position * realised_change
    # Trading cost is paid only when the target position changes.
    net_pnl = gross_pnl - (position_change * one_way_cost)
    return net_pnl.rename(signal.name if signal.name is not None else 'net_pnl')


def compute_position_turnover(signal: pd.Series) -> float:
    """Compute average one-way turnover from changes in target position."""
    position = np.sign(signal).fillna(0)
    position_change = position.diff().abs().fillna(position.abs())
    return float(position_change.mean())


def compute_sharpe_raw(pnl: pd.Series, periods_per_year: int = 252) -> float:
    """Compute a raw-dollar Sharpe ratio on daily persistent-position PnL."""
    clean = pnl.dropna()
    if clean.shape[0] < 2 or clean.std(ddof=1) == 0:
        return np.nan
    return float(clean.mean() / clean.std(ddof=1) * np.sqrt(periods_per_year))


def compute_sortino_raw(pnl: pd.Series, periods_per_year: int = 252) -> float:
    """Compute a raw-dollar Sortino ratio on daily persistent-position PnL."""
    clean = pnl.dropna()
    if clean.shape[0] < 2:
        return np.nan

    # Sortino uses downside deviation as the volatility measure, which only penalises negative returns.
    downside_diff = clean.clip(upper=0)
    downside_deviation = float(np.sqrt(np.mean(np.square(downside_diff))))
    if downside_deviation == 0:
        return np.nan
    return float(clean.mean() / downside_deviation * np.sqrt(periods_per_year))


def compute_drawdown_stats(pnl: pd.Series) -> dict:
    """Compute drawdown depth and dates on a cumulative dollar PnL curve."""
    clean = pnl.dropna()
    if clean.empty:
        return {
            'max_drawdown': np.nan,
            'peak_date': None,
            'trough_date': None,
            'recovery_date': None,
        }

    equity_curve = clean.cumsum()
    # Drawdown is measured from the running peak of the cumulative PnL curve.
    running_peak = equity_curve.cummax()
    drawdown = equity_curve - running_peak
    trough_date = drawdown.idxmin()
    peak_date = equity_curve.loc[:trough_date].idxmax()
    peak_level = running_peak.loc[peak_date]
    post_trough = equity_curve.loc[trough_date:]
    # Recovery is the first time the equity curve gets back to the prior peak.
    recovery_candidates = post_trough[post_trough >= peak_level]
    recovery_date = recovery_candidates.index[0] if not recovery_candidates.empty else None

    return {
        'max_drawdown': float(drawdown.min()),
        'peak_date': peak_date,
        'trough_date': trough_date,
        'recovery_date': recovery_date,
    }


def compute_top_drawdowns(pnl: pd.Series, top_n: int = 5) -> pd.DataFrame:
    """Return the top drawdown troughs for a cumulative dollar PnL curve."""
    clean = pnl.dropna()
    if clean.empty:
        return pd.DataFrame(columns=['peak_date', 'trough_date', 'drawdown'])

    equity_curve = clean.cumsum()
    running_peak = equity_curve.cummax()
    drawdown = (equity_curve - running_peak).sort_values().head(top_n)
    rows = []

    for trough_date, drawdown_value in drawdown.items():
        peak_date = equity_curve.loc[:trough_date].idxmax()
        rows.append({
            'peak_date': peak_date,
            'trough_date': trough_date,
            'drawdown': drawdown_value,
        })

    return pd.DataFrame(rows)


def assign_signal_buckets(signal: pd.Series, n_buckets: int = 5) -> pd.Series:
    """Assign a signal series into quantile buckets across time."""
    bucket_name = f'{signal.name}_bucket' if signal.name is not None else 'signal_bucket'
    non_na = signal.dropna()
    if non_na.empty:
        return pd.Series(pd.NA, index=signal.index, name=bucket_name, dtype='object')

    # Bucket on the raw signal values so tied observations stay together rather
    # than being split into different buckets by row order.
    try:
        _, bin_edges = pd.qcut(
            non_na,
            q=min(n_buckets, non_na.shape[0]),
            retbins=True,
            duplicates='drop',
        )
    except ValueError:
        return pd.Series(pd.NA, index=signal.index, name=bucket_name, dtype='object')

    if len(bin_edges) < 2:
        return pd.Series(pd.NA, index=signal.index, name=bucket_name, dtype='object')

    labels = [f'Q{i}' for i in range(1, len(bin_edges))]
    bucket_dtype = pd.CategoricalDtype(categories=labels, ordered=True)
    bucketed = pd.cut(non_na, bins=bin_edges, labels=labels, include_lowest=True).astype(bucket_dtype)
    result = pd.Series(pd.Categorical([pd.NA] * len(signal), dtype=bucket_dtype), index=signal.index, name=bucket_name)
    result.loc[bucketed.index] = bucketed
    return result


def compute_bucket_stats(signal: pd.Series, forward_change: pd.Series, n_buckets: int = 5) -> tuple[pd.DataFrame, float]:
    """Compute forward dollar-change statistics by signal bucket."""
    aligned = pd.concat([signal.rename('signal'), forward_change.rename('forward_change')], axis=1).dropna()
    if aligned.empty:
        return pd.DataFrame(columns=['count', 'mean', 'median', 'hit_rate']), np.nan

    aligned['bucket'] = assign_signal_buckets(aligned['signal'], n_buckets=n_buckets)
    aligned = aligned.dropna(subset=['bucket'])
    if aligned.empty:
        return pd.DataFrame(columns=['count', 'mean', 'median', 'hit_rate']), np.nan

    bucket_stats = aligned.groupby('bucket', observed=False)['forward_change'].agg(['count', 'mean', 'median'])
    
    # Flip realised changes by signal direction so a correct short call counts as a hit.
    aligned['directional_change'] = aligned['forward_change'] * np.sign(aligned['signal'])
    bucket_stats['hit_rate'] = aligned.groupby('bucket', observed=False)['directional_change'].apply(lambda x: (x > 0).mean())

    valid_means = bucket_stats['mean'].dropna()
    top_minus_bottom = float(valid_means.iloc[-1] - valid_means.iloc[0]) if valid_means.shape[0] >= 2 else np.nan
    return bucket_stats, top_minus_bottom


def classify_term_structure(spread: pd.Series, flat_threshold: float = 0.10) -> pd.Series:
    """Classify term structure into backwardation, flat, or contango."""
    regime = pd.Series('flat', index=spread.index, dtype=object)
    regime[spread > flat_threshold] = 'backwardation'
    regime[spread < -flat_threshold] = 'contango'
    return regime.rename('term_structure_regime')


def classify_vol_regime(
    price_chg: pd.Series,
    vol_window: int = 21,
    pct_lookback: int = 252,
    high_pct: float = 0.8,
    low_pct: float = 0.2,
) -> pd.Series:
    """Classify vol regime via rolling realised vol percentile rank over a fixed lookback window."""
    realized_vol = price_chg.rolling(window=vol_window, min_periods=vol_window).std()
    # Compare today's realised vol with its own trailing history.
    pct_rank = realized_vol.rolling(window=pct_lookback, min_periods=pct_lookback).apply(
        lambda x: (x <= x[-1]).mean(), raw=True
    )
    regime = pd.Series('normal', index=price_chg.index, dtype=object)
    regime[pct_rank > high_pct] = 'high'
    regime[pct_rank <= low_pct] = 'low'
    return regime.rename('vol_regime')


def summarise_regime(
    signal: pd.Series,
    forward_change: pd.Series,
    net_pnl: pd.Series,
    regime: pd.Series,
) -> pd.DataFrame:
    """Summarise predictive correlation and realised PnL by regime."""
    aligned = pd.concat([
        signal.rename('signal'),
        forward_change.rename('forward_change'),
        net_pnl.rename('net_pnl'),
        regime.rename('regime'),
    ], axis=1).dropna()

    rows = []
    for regime_name, grouped in aligned.groupby('regime'):
        # Compute IC and realised performance inside each regime independently.
        spearman_stats = compute_predictive_corr_stats(grouped['signal'], grouped['forward_change'], method='spearman')
        pearson_stats = compute_predictive_corr_stats(grouped['signal'], grouped['forward_change'], method='pearson')
        rows.append({
            'regime': regime_name,
            'n_obs': grouped.shape[0],
            'spearman_ic': spearman_stats['corr'],
            'pearson_ic': pearson_stats['corr'],
            'ic_t_stat': spearman_stats['t_stat'],
            'avg_net_pnl': grouped['net_pnl'].mean(),
            'hit_rate': (grouped['net_pnl'] > 0).mean(),
            'sharpe': compute_sharpe_raw(grouped['net_pnl']),
        })

    return pd.DataFrame(rows).set_index('regime').sort_index()


def plot_signal_regime_summary(summary_df: pd.DataFrame, signal_name: str, regime_name: str) -> None:
    """Plot side-by-side IC and net PnL for a single signal and regime family."""
    fig, axes = plt.subplots(ncols=2, figsize=(12, 4))
    colours = sns.color_palette('Set2', n_colors=summary_df.shape[0])

    summary_df['spearman_ic'].plot(kind='bar', ax=axes[0], color=colours)
    summary_df['avg_net_pnl'].plot(kind='bar', ax=axes[1], color=colours)

    axes[0].set_title(f'{signal_name.title()} -- IC by {regime_name}')
    axes[1].set_title(f'{signal_name.title()} -- Net P&L by {regime_name}')
    axes[0].set_ylabel('Spearman IC')
    axes[1].set_ylabel('Average Net $ Change')
    axes[0].axhline(0, c='black', lw=0.8, ls='--')
    axes[1].axhline(0, c='black', lw=0.8, ls='--')
    plt.tight_layout()
    plt.show()


def orthogonalise_signal_expanding(
    signal: pd.Series,
    other_signals: pd.DataFrame,
    min_history: int = 252,
) -> tuple[pd.Series, pd.Series]:
    """Residualise a signal against peers using only information available up to each date."""
    aligned = pd.concat([signal.rename('target'), other_signals], axis=1).dropna()
    residuals = {}
    r_squared = {}

    for row_idx in range(min_history, aligned.shape[0]):
        # Fit only on data available before the current timestamp.
        train = aligned.iloc[:row_idx]
        current = aligned.iloc[[row_idx]]
        X_train = sm.add_constant(train[other_signals.columns], has_constant='add')
        fit = sm.OLS(train['target'], X_train).fit()
        X_current = sm.add_constant(current[other_signals.columns], has_constant='add')

        # The residual is the portion of the target signal not explained by peers.
        predicted = float(fit.predict(X_current).iloc[0])
        current_date = current.index[0]
        residuals[current_date] = float(current['target'].iloc[0] - predicted)
        r_squared[current_date] = float(fit.rsquared)

    return pd.Series(residuals, name=signal.name), pd.Series(r_squared, name=f'{signal.name}_expanding_r_squared')


def orthogonalise_signals_expanding_sequential(
    signals: pd.DataFrame,
    min_history: int = 252,
    normalise_window: int = 60,
) -> tuple[pd.DataFrame, pd.Series]:
    """Orthogonalise signals sequentially using only expanding-window information.

    The first signal in ``signals.columns`` is kept as the anchor signal. Each
    subsequent signal is residualised against the already-orthogonalised signals
    that come before it, following a Qian-style ordered construction. Every
    resulting component is then scaled by its lagged rolling standard deviation
    so the downstream backtest works with comparable signal magnitudes.

    Parameters
    ----------
    signals:
        Ordered DataFrame of raw signals. Column order determines the
        sequential orthogonalisation order.
    min_history:
        Minimum number of observations required before the first expanding
        regression is fit.
    normalise_window:
        Rolling window used to volatility-scale each orthogonal component.

    Returns
    -------
    tuple[pd.DataFrame, pd.Series]
        A DataFrame of sequentially orthogonalised signals and a Series of mean
        expanding-window R-squared values. The anchor signal is not regressed on
        earlier components, so its reported R-squared is ``NaN``.
    """
    orth_signals: dict[str, pd.Series] = {}
    mean_r_squared: dict[str, float] = {}

    for column_idx, signal_name in enumerate(signals.columns):
        raw_signal = signals[signal_name]

        if column_idx == 0:
            component = raw_signal.copy()
            mean_r_squared[signal_name] = np.nan
        else:
            regressors = pd.DataFrame({
                prev_name: orth_signals[prev_name].reindex(signals.index)
                for prev_name in signals.columns[:column_idx]
            })
            component, expanding_r2 = orthogonalise_signal_expanding(
                raw_signal,
                regressors,
                min_history=min_history,
            )
            mean_r_squared[signal_name] = float(expanding_r2.mean())

        rolling_std = component.rolling(window=normalise_window, min_periods=normalise_window).std().shift()
        orth_signals[signal_name] = (component / rolling_std).rename(signal_name)

    orth_signals_df = pd.DataFrame(orth_signals).dropna()
    return orth_signals_df, pd.Series(mean_r_squared, name='mean_expanding_r_squared')


def orthogonalise_signals_full_sample_sequential(
    signals: pd.DataFrame,
    normalise_window: int = 60,
) -> tuple[pd.DataFrame, pd.Series]:
    """Orthogonalise signals sequentially on the full sample for ex post attribution.

    The first signal in ``signals.columns`` is kept as the anchor. Each
    subsequent signal is residualised against the already-orthogonalised signals
    that come before it, following a Qian-style ordered construction on the
    full sample. The resulting components are then scaled by lagged rolling
    standard deviation so downstream comparisons use comparable magnitudes.

    Parameters
    ----------
    signals:
        Ordered DataFrame of raw signals. Column order defines the sequential
        orthogonalisation order.
    normalise_window:
        Rolling window used to volatility-scale each orthogonal component.

    Returns
    -------
    tuple[pd.DataFrame, pd.Series]
        A DataFrame of full-sample sequentially orthogonalised signals and a
        Series of regression R-squared values. The anchor signal is not
        regressed on earlier components, so its reported R-squared is ``NaN``.
    """
    orth_signals: dict[str, pd.Series] = {}
    r_squared: dict[str, float] = {}

    for column_idx, signal_name in enumerate(signals.columns):
        raw_signal = signals[signal_name]

        if column_idx == 0:
            component = raw_signal.copy()
            r_squared[signal_name] = np.nan
        else:
            regressors = pd.DataFrame({
                prev_name: orth_signals[prev_name].reindex(signals.index)
                for prev_name in signals.columns[:column_idx]
            })
            aligned = pd.concat([raw_signal.rename('target'), regressors], axis=1).dropna()
            X = sm.add_constant(aligned[regressors.columns], has_constant='add')
            fit = sm.OLS(aligned['target'], X).fit()
            predicted = fit.predict(X)
            component = (aligned['target'] - predicted).rename(signal_name)
            r_squared[signal_name] = float(fit.rsquared)

        rolling_std = component.rolling(window=normalise_window, min_periods=normalise_window).std().shift()
        orth_signals[signal_name] = (component / rolling_std).rename(signal_name)

    orth_signals_df = pd.DataFrame(orth_signals).dropna()
    return orth_signals_df, pd.Series(r_squared, name='full_sample_r_squared')
